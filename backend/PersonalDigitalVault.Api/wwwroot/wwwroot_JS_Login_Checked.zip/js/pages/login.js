import { authApi } from '../api/authApi.js';
import { tokenManager } from '../auth/tokenManager.js';

const form = document.querySelector('form');
const message = document.getElementById('message');
const submitButton = form?.querySelector('button[type="submit"], button:not([type])');

form?.addEventListener('submit', async (event) => {
    event.preventDefault();

    message.textContent = '';

    if (submitButton) {
        submitButton.disabled = true;
        submitButton.textContent = 'Signing in...';
    }

    try {
        const result = await authApi.login({
            email: form.email.value.trim(),
            password: form.password.value
        });

        if (!result || !result.token) {
            console.error('Login response token missing:', result);
            throw new Error('Login response-la JWT token varala. Backend LoginResponseDto check pannunga.');
        }

        tokenManager.set(result.token);
        window.location.href = '/html/dashboard.html';
    } catch (error) {
        console.error('Login failed:', error);
        message.textContent = error.message || 'Login failed.';
    } finally {
        if (submitButton) {
            submitButton.disabled = false;
            submitButton.textContent = 'Login securely';
        }
    }
});
