const KEY='pdv_token'; export const tokenManager={get:()=>localStorage.getItem(KEY),set:t=>localStorage.setItem(KEY,t),clear:()=>localStorage.removeItem(KEY)};
