import{tokenManager}from'./tokenManager.js'; export function requireAuth(){if(!tokenManager.get())location.href='/html/login.html';}
